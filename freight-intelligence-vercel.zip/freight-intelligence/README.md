# FreightIQ

A Vercel-ready SIH prototype for intelligent freight forecasting, vessel chartering and bulk cargo procurement planning for India's East Coast.

## Stack
- Next.js + TypeScript
- Prisma + PostgreSQL
- bcrypt password hashing + signed HTTP-only session cookie
- Recharts
- Designed to connect to an OR-Tools/Pyomo/PuLP optimization service

## Local setup
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` and `AUTH_SECRET`.
3. `npm install`
4. `npx prisma migrate dev --name init`
5. `npm run dev`
6. Open http://localhost:3000

## Vercel
1. Push this repository to GitHub.
2. Import it into Vercel.
3. Add `DATABASE_URL` and `AUTH_SECRET` in Vercel Project Settings → Environment Variables.
4. Build command: `npx prisma generate && next build`
5. Use a hosted PostgreSQL provider (Neon, Supabase, Prisma Postgres, etc.) and run the migration against it.

## Important
The forecast and optimizer currently contain clearly labeled illustrative calculations so the application works immediately. For an SIH submission, replace those functions with validated datasets and a real forecasting/optimization pipeline. Never present sample numbers as live commercial shipping data.
